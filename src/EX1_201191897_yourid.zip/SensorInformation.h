#ifndef __SENSOR_INFORMATION__H_
#define __SENSOR_INFORMATION__H_

struct SensorInformation 
{ 
    int dirtLevel; 
    bool isWall[4]; 
};

#endif //__SENSOR_INFORMATION__H_