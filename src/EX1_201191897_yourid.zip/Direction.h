#ifndef __DIRECTION__H_
#define __DIRECTION__H_

enum class Direction {East=0, West, South, North, Stay};

#endif //__DIRECTION__H_
